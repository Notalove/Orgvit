import cv2
import numpy as np
import glob

root = "./data/VOCdevkit/VOC2012/"
savePath = root + "SegVis/"
jpgimgs = root + "JPEGImages/*.jpg"
pngimgs = root + "SegmentationClass/"

for i,jpg_img_path in enumerate(glob.glob(jpgimgs)):
    print(jpgimgs)
    jpg_img_name = jpg_img_path.split("/")[-1]
    print(jpg_img_name)
    png_img_name = jpg_img_name.split(".")[0] + ".png"
    png_img_path = pngimgs + png_img_name
    vis_img_path = savePath + jpg_img_name
    jpg_img = cv2.imread(jpg_img_path)
    png_img = cv2.imread(png_img_path, 0)
    mask = np.zeros((png_img.shape[0],png_img.shape[1],3))
    print(np.where(png_img==1))
    mask[np.where(png_img==1),0] = 255
    mask[np.where(png_img==2),1] = 255
    mask[np.where(png_img==3),2] = 255
    print(mask.shape)
    print(jpg_img.shape,png_img.shape)
    vis_img = jpg_img * 0.5 + mask * 0.5 
    # vis_img.astype(np.uint8)
    cv2.imshow("vis",mask)
    cv2.waitKey(0)
